class Example3 extends Phaser.Scene{
    constructor(){
        super({key:'Example3'})
    }
    preload(){
        this.load.audio('audio1','./Assets/Shot.wav')
    }
    create(){
        gameState.audio1=this.sound.add('audio1',{loop:'true'})
        gameState.audio1.play();
        
    }
}