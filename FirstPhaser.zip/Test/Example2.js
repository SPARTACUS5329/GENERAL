class Example2 extends Phaser.Scene{
    constructor(){
        super({key:'Example2'});
    };
    create(){
        gameState.text=this.add.text(300,300,'Welcome to Example2',{font:'40px Impact'})
        gameState.tween1=this.tweens.add({
            targets:gameState.text,
            x:200,
            y:250,
            duration:2000,
            ease:'Linear',
            easeParams:[1.5,0.5],
            delay:1000,
            onComplete:function(src,tgt){
                tgt[0].x=0;
                tgt[0].y=0;
                tgt[0].setColor('Red')
            }
        },this)
        this.input.keyboard.on('keyup',function(event){
            if (event.key==='1'){
                this.scene.start('Example1')
            }
            else if(event.key==='3'){
                this.scene.start('Example3')
            }
        },this)
    }
}