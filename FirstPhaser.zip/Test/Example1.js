class Example1 extends Phaser.Scene {
    constructor(){
        super({key: 'Example1'})
    }

    preload(){
        this.load.image('dino','./Assets/sonic.png',{ frameWidth: 32, frameHeight: 32})
    }

    create(){
        gameState.image = this.add.image(400,300,'dino')[1]
        console.log(gameState.image.x)
        /*this.input.on('pointerdown',function(event){
                gameState.image.x=event.x;
                gameState.image.y=event.y;
        })*/
        gameState.keyA = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.A);
        gameState.keyD = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.D);
        gameState.keyS = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.S);
        gameState.keyW = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.W);
        /*this.input.keyboard.on('keyup_P',function(event){
            gameState.physicsImage=this.physics.add.image(gameState.image.x,gameState.image.y,'dino')
            gameState.physicsImage.setVelocity(Phaser.Math.RND.integerInRange(-100,100),-300)
        },this)
        this.input.keyboard.on('keyup',function(event){
            switch (event.key){
                case '2':
                    this.scene.start('Example2');
                case '3':
                    this.scene.start('Example3');
            }
        },this) */
    }

    update(event){
        if (gameState.keyA.isDown){
            gameState.image.x--;
        }
        if (gameState.keyD.isDown){
            gameState.image.x++
        }
        if (gameState.keyW.isDown){
            gameState.image.y--;
        }
        if (gameState.keyS.isDown){
            gameState.image.y++;
        }
    }
}

const gameState={

};

